<link href="CSS/style.css" rel="stylesheet" type="text/css"/>
<div class="footer">
    <center>
        Последняя любовь
    <br> Жданов Владимир 2020 год
    </center>
</div>


