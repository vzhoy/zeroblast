<?php
session_start();

$_SESSION['login']=$_POST['login'];
include 'database.php';

$login=$_POST['login'];
$password=$_POST['password'];
$sqli="SELECT `login`,`password` FROM `users` WHERE `login`= '$login' AND `password`='$password'";
$rows= mysqli_query($sql, $sqli);
$rows->num_rows;
if ($rows->num_rows>0){
header('location:../index.php');
}
else
{
echo'Повторите ввод логина и пароля <a href="../login.php">Вернуться</a>';
exit();
}
        

      
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

