<?php
$password='';
$username='root';
$database='last_love';
$localhost='localhost';
$sql=mysqli_connect($localhost, $username, $password,  $database);
if ($sql== TRUE){

}
 else {
$sql->error;
}

?>


