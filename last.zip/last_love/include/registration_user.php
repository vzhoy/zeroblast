<link href="CSS/style.css" rel="stylesheet" type="text/css"/>
<?php
  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
include 'database.php';
$login=(trim($_POST['login']));
$firstname=(trim($_POST['firstname']));
$lastname=(trim($_POST['lastname']));
$birthday=$_POST['date'];
$password=(trim($_POST['password']));
$sex=$_POST['sex'];

if (empty($login)){
    echo 'Введите логин <a href=../registration.php>Вернуться</a>';
    exit();
}
if (empty($firstname)){
    echo 'Введите имя <a href=../registration.php>Вернуться</a>';
    exit();
}
if (empty($lastname)){
    echo 'Введите Фамилию <a href=../registration.php>Вернуться</a>';
    exit();
}
if (empty($birthday)){
    echo 'Введите дату рождения <a href=../registration.php>Вернуться</a>';
exit();
}
if (empty($password)){
    echo 'Введите пароль <a href=../registration.php>Вернуться</a>';
exit();  
}
$sqli="SELECT `login`FROM `users` WHERE `login`= '$login'";
$rows= mysqli_query($sql, $sqli);
$rows->num_rows;
if ($rows->num_rows>0){
    echo "Такой логин уже занят, пожалуйста выберите другой ";
}
else
{
    if ($sex == 1){
    $query="INSERT INTO `users`(`first_name`, `last_name`, `data_birth`, `login`, `password`, `sex`) VALUES ('$firstname','$lastname','$birthday','$login','$password','Мужской')";
    }
    if ($sex == 2){
    $query="INSERT INTO `users`(`first_name`, `last_name`, `data_birth`, `login`, `password`, `sex`) VALUES ('$firstname','$lastname','$birthday','$login','$password','Женский')";
    }
    $result= mysqli_query($sql, $query);
if ($result==TRUE){
  echo  "<div class=forma> Вы зарегистрированы теперь <a href=../login.php>авторизуйтесь</a></div>";
}
 else {
  
}
}
?>






